// tests/helpers/seed.ts
import bcrypt from "bcrypt";
import { DataSource } from "typeorm";

export async function seedBase(ds: DataSource) {
  const email = "admin@acme.com";
  const pwd = "admin123"; // se o DTO exige senha forte, troque p/ "Admin@123"
  const hash = await bcrypt.hash(pwd, 4);

  // Permissões (ajuste PONTO vs DOIS-PONTOS conforme seu middleware)
  await ds.query(
    `INSERT INTO permissions (code, description) VALUES
      ('users.read','List users'),
      ('me.read','Read profile')
     ON CONFLICT (code) DO NOTHING`
  );

  await ds.query(
    `INSERT INTO role_permissions (role, permission_code)
     SELECT 'admin', c FROM (VALUES ('users.read'), ('me.read')) v(c)
     WHERE NOT EXISTS (
       SELECT 1 FROM role_permissions rp
       WHERE rp.role='admin' AND rp.permission_code=v.c
     )`
  );

  await ds.query(
    `INSERT INTO users (name, email, role, password_hash)
     VALUES ($1::varchar, $2::varchar, $3::varchar, $4::varchar)
     ON CONFLICT (email) DO NOTHING`,
    ["Admin", email, "admin", hash]
  );

  // garante hash correto no admin (sobrescreve qualquer coisa antiga)
  await ds.query(
    `UPDATE users SET password_hash = $1::varchar, role = 'admin', deleted_at = NULL
     WHERE email = $2::varchar`,
    [hash, email]
  );
}
