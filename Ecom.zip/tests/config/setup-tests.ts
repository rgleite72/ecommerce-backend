// tests/config/setup-tests.ts
// Tipos globais locais (valem só neste arquivo)
import type supertest from "supertest";
import type { DataSource } from "typeorm";

declare global {

  var http: () => ReturnType<typeof supertest>;

  var ds: () => DataSource;
}
export {};



if (process.env.TEST_KIND !== "integration") {
  // Sai cedo: não carrega nada pesado
  // Mantém o arquivo inofensivo para testes unitários
} else {
  // Tudo dentro de um escopo assíncrono para evitar imports no topo
  (async () => {
    const path = await import("path");
    const dotenv = await import("dotenv");
    dotenv.config({ path: path.resolve(process.cwd(), ".env.test") });

    const { beforeAll, afterAll } = await import("@jest/globals");
    const supertest = (await import("supertest")).default;

    const { appDataSource } = await import("../../src/app/db/data-source");
    const { createApp } = await import("../../src/app/app");
    const { seedBase } = await import("../helpers/seed");

    let agent: ReturnType<typeof supertest> | null = null;

    beforeAll(async () => {
      if (!appDataSource.isInitialized) await appDataSource.initialize();
      await appDataSource.synchronize(true);
      await seedBase(appDataSource);

      const app = createApp();
      agent = supertest(app);
    });

    afterAll(async () => {
      if (appDataSource.isInitialized) await appDataSource.destroy();
      agent = null;
    });

    // expõe helpers globais (opcional)

  (global as typeof globalThis).http = () => {
    if (!agent) throw new Error("Agent não inicializado");
    return agent;
  };
   
    (global as typeof globalThis).ds = () => appDataSource;
  })();
}
