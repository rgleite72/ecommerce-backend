import request from "supertest";
import type { Express } from "express";
import {  describe, it, expect } from '@jest/globals';

declare const testApp: Express;
declare const loginAs: (email: string, password: string) => Promise<{ accessToken: string; refreshToken?: string }>;

describe("RBAC — authenticateJWT + authorize/permit", () => {
  it("sem token → 401", async () => {
    const r = await request(testApp).get("/api/admin/users");
    expect(r.status).toBe(401);
  });

  it("user em rota admin → 403", async () => {
    const { accessToken } = await loginAs("user@acme.com", "User#123");
    const r = await request(testApp).get("/api/admin/users").set("Authorization", `Bearer ${accessToken}`);
    expect(r.status).toBe(403);
  });

  it("admin em rota admin → 200", async () => {
    const { accessToken } = await loginAs("admin@acme.com", "Admin#123");
    const r = await request(testApp).get("/api/admin/users").set("Authorization", `Bearer ${accessToken}`);
    expect(r.status).toBe(200);
    expect(Array.isArray(r.body.data)).toBe(true);
  });

  it("qualquer autenticado acessa /users/me → 200 sem passwordHash", async () => {
    const { accessToken } = await loginAs("user@acme.com", "User#123");
    const r = await request(testApp).get("/api/users/me").set("Authorization", `Bearer ${accessToken}`);
    expect(r.status).toBe(200);
    expect(r.body).toMatchObject({ email: "user@acme.com", role: "user" });
    expect(r.body.passwordHash).toBeUndefined();
  });
});
