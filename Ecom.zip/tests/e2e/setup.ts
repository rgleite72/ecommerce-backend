import "reflect-metadata";
import { AppDataSource } from "../../src/app/db/data-source";
import { createApp } from "../../src/app/app";
import type { Express } from "express";
import request from "supertest";
import * as bcrypt from "bcryptjs"; // ajuste para argon2 se usar
import { Repository } from "typeorm";

import { UserEntity } from "../../src/modules/users/domain/entities/user.entity";
import { PermissionEntity } from "../../src/modules/rbac/domain/entities/permission.entity";
import { RolePermissionEntity } from "../../src/modules/rbac/domain/entities/role-permission.entity";
import { beforeAll, afterAll,  expect } from '@jest/globals';


let app: Express;

declare global {

  var testApp: Express;

  var loginAs: (email: string, password: string) => Promise<{ accessToken: string; refreshToken?: string }>;
}

beforeAll(async () => {
  process.env.NODE_ENV = "test";

  await AppDataSource.initialize();
  await AppDataSource.runMigrations();

  await seedPermissionsAndRoles();
  await seedUsers();

  app = createApp();
  global.testApp = app;

  global.loginAs = async (email: string, password: string) => {
    const res = await request(app).post("/api/auth/login").send({ email, password });
    expect([200, 201]).toContain(res.status);
    expect(res.body?.accessToken).toBeDefined();
    return { accessToken: res.body.accessToken, refreshToken: res.body.refreshToken };
  };
});

afterAll(async () => {
  if (AppDataSource.isInitialized) {
    await AppDataSource.destroy();
  }
});

async function seedPermissionsAndRoles() {
  const permRepo: Repository<PermissionEntity> = AppDataSource.getRepository(PermissionEntity);
  const rpRepo: Repository<RolePermissionEntity> = AppDataSource.getRepository(RolePermissionEntity);

  // upsert permissões mínimas
  const perms = [
    { code: "users.read",   description: "Listar e consultar usuários" },
    { code: "users.create", description: "Criar usuários" },
    { code: "users.update", description: "Atualizar usuários" },
    { code: "users.delete", description: "Excluir usuários" },
    { code: "me.read",      description: "Ler perfil próprio" },
    { code: "me.update",    description: "Atualizar perfil próprio" },
  ];
  for (const p of perms) {
    const exists = await permRepo.findOne({ where: { code: p.code } });
    if (!exists) await permRepo.save(permRepo.create(p));
  }

  // papel → permissões
  const rolePerms: Record<"user"|"admin", string[]> = {
    user:  ["me.read", "me.update"],
    admin: ["me.read", "me.update", "users.read", "users.create", "users.update", "users.delete"],
  };
  for (const [role, codes] of Object.entries(rolePerms) as [("user"|"admin"), string[]][]) {
    for (const code of codes) {
      const exists = await rpRepo.findOne({ where: { role, permissionCode: code } });
      if (!exists) await rpRepo.save(rpRepo.create({ role, permissionCode: code }));
    }
  }
}

async function seedUsers() {
  const repo = AppDataSource.getRepository(UserEntity);
  await repo.createQueryBuilder().delete().from(UserEntity).execute();

  const admin = repo.create({
    name: "Admin",
    email: "admin@acme.com",
    role: "admin",
    passwordHash: await bcrypt.hash("Admin#123", 10),
  });
  const user = repo.create({
    name: "User",
    email: "user@acme.com",
    role: "user",
    passwordHash: await bcrypt.hash("User#123", 10),
  });

  await repo.save([admin, user]);
}
