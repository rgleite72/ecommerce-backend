import request from "supertest";
import type { Express } from "express";
import jwt from "jsonwebtoken";
import {  describe, it, expect } from '@jest/globals';

declare const testApp: Express;

describe("Auth — Login, Refresh, Logout", () => {
  it("login ok (admin)", async () => {
    const r = await request(testApp).post("/api/auth/login").send({ email: "admin@acme.com", password: "Admin#123" });
    expect(r.status).toBe(200);
    expect(r.body).toHaveProperty("accessToken");
    // se sua API já devolve refreshToken:
    expect(r.body).toHaveProperty("refreshToken");
  });

  it("login erro (credenciais inválidas)", async () => {
    const r = await request(testApp).post("/api/auth/login").send({ email: "admin@acme.com", password: "WRONG" });
    expect([401, 400]).toContain(r.status);
  });

  it("access expirado → 401 no authenticateJWT", async () => {
    const secret = process.env.JWT_ACCESS_SECRET || "test-secret";
    const tok = jwt.sign({ sub: "fake-id", email: "fake@x.com", role: "user" }, secret, { algorithm: "HS256", expiresIn: "1s" });
    await new Promise(r => setTimeout(r, 1200)); // expira
    const res = await request(testApp).get("/api/users/me").set("Authorization", `Bearer ${tok}`);
    expect(res.status).toBe(401);
  });

  it("refresh válido → novo access", async () => {
    const login = await request(testApp).post("/api/auth/login").send({ email: "admin@acme.com", password: "Admin#123" });
    const refresh = login.body.refreshToken;
    expect(refresh).toBeDefined();

    const res = await request(testApp).post("/api/auth/refresh").send({ refreshToken: refresh });
    expect([200, 201]).toContain(res.status);
    expect(res.body).toHaveProperty("accessToken");
  });

  it("refresh inválido → 400/401", async () => {
    const res = await request(testApp).post("/api/auth/refresh").send({ refreshToken: "xxx.invalid.yyy" });
    expect([400, 401]).toContain(res.status);
  });

  it("logout (revogação de 1 sessão) → refresh antigo falha", async () => {
    const login = await request(testApp).post("/api/auth/login").send({ email: "admin@acme.com", password: "Admin#123" });
    const { accessToken, refreshToken } = login.body;
    expect(refreshToken).toBeDefined();

    const out = await request(testApp)
      .post("/api/auth/logout")
      .set("Authorization", `Bearer ${accessToken}`)
      .send({ refreshToken });
    expect([200, 204]).toContain(out.status);

    const again = await request(testApp).post("/api/auth/refresh").send({ refreshToken });
    expect([401, 400, 403]).toContain(again.status);
  });

  it("logout-all (revogação total) → todos refresh antigos falham", async () => {
    const l1 = await request(testApp).post("/api/auth/login").send({ email: "admin@acme.com", password: "Admin#123" });
    const l2 = await request(testApp).post("/api/auth/login").send({ email: "admin@acme.com", password: "Admin#123" });

    const outAll = await request(testApp)
      .post("/api/auth/logout-all")
      .set("Authorization", `Bearer ${l2.body.accessToken}`)
      .send();
    expect([200, 204]).toContain(outAll.status);

    const r1 = await request(testApp).post("/api/auth/refresh").send({ refreshToken: l1.body.refreshToken });
    const r2 = await request(testApp).post("/api/auth/refresh").send({ refreshToken: l2.body.refreshToken });
    expect([401, 400, 403]).toContain(r1.status);
    expect([401, 400, 403]).toContain(r2.status);
  });
});
