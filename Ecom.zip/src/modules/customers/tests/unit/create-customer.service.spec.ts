import { InMemoryCustomersRepository } from "../doubles/in-memory-customers.repository";
import { CreateCustomerService } from "../../services/create-customer.service";
import { makeCreateCustomerDTO } from "../fixtures/customer.fixture";
import { AppError } from "../../../../shared/errors/AppError";

describe("CreateCustomerService", () => {
  it("cria um customer com e-mail único", async () => {
    const repo = new InMemoryCustomersRepository();
    const sut = new CreateCustomerService(repo);

    const dto = makeCreateCustomerDTO({ email: "john@acme.com" });
    const created = await sut.execute(dto);

    expect(created.id).toBeDefined();
    expect(created.email).toBe("john@acme.com");
  });

  it("lança 409 se e-mail já existir", async () => {
    const repo = new InMemoryCustomersRepository();
    const sut = new CreateCustomerService(repo);

    await sut.execute(makeCreateCustomerDTO({ email: "dup@acme.com" }));
    await expect(sut.execute(makeCreateCustomerDTO({ email: "dup@acme.com" })))
      .rejects.toEqual(new AppError("E-mail já utilizado", 409));
  });
});
