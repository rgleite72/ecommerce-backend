// src/modules/customers/tests/services/update-customer.service.spec.ts
import { InMemoryCustomersRepository } from "../doubles/in-memory-customers.repository";
import { CreateCustomerService } from "../../services/create-customer.service";
import { UpdateCustomerService } from "../../services/update-customer.service";
import { makeCreateCustomerDTO } from "../fixtures/customer.fixture";
import { AppError } from "../../../../shared/errors/AppError";

describe("UpdateCustomerService", () => {
  let repo: InMemoryCustomersRepository;
  let createCustomer: CreateCustomerService;
  let sut: UpdateCustomerService;

  beforeEach(() => {
    repo = new InMemoryCustomersRepository();
    createCustomer = new CreateCustomerService(repo);
    sut = new UpdateCustomerService(repo);
  });

  it("atualiza nome e email, toca updatedAt e preserva createdAt", async () => {
    // Arrange
    const created = await createCustomer.execute(
      makeCreateCustomerDTO({ name: "Alice", email: "alice@ACME.com" })
    );
    const id = created.id;
    const beforeUpdatedMs = created.updatedAt!.getTime();
    const beforeCreatedMs = created.createdAt.getTime();

    // Act
    const input = { name: "Alice Silva", email: "alice.silva@acme.com" };
    const result = await sut.execute(id, input);

    // Assert
    expect(result).toBeDefined();
    expect(result.id).toBe(id);
    expect(result.name).toBe("Alice Silva");
    expect(result.email).toBe("alice.silva@acme.com");
    expect(result.createdAt.getTime()).toBe(beforeCreatedMs);
    expect(result.updatedAt!.getTime()).toBeGreaterThan(beforeUpdatedMs);
    expect(result.deletedAt).toBeNull();
  });

  it("suporta atualização parcial de nome DESDE QUE envie o email atual (DTO exige email)", async () => {
    // Arrange
    const created = await createCustomer.execute(
      makeCreateCustomerDTO({ name: "Bob", email: "bob@acme.com" })
    );
    const id = created.id;

    // Act — como o DTO exige email, mandamos o mesmo email atual
    const partial = { name: "Bob Jr.", email: created.email };
    const result = await sut.execute(id, partial);

    // Assert
    expect(result.name).toBe("Bob Jr.");
    expect(result.email).toBe("bob@acme.com");
  });

  it("normaliza e-mail para minúsculas ao atualizar", async () => {
    // Arrange
    const created = await createCustomer.execute(
      makeCreateCustomerDTO({ email: "CASE@EXAMPLE.COM" })
    );

    // Act
    const updated = await sut.execute(created.id, { name: created.name, email: "UPPER@EXAMPLE.COM" });

    // Assert
    expect(updated.email).toBe("upper@example.com");
  });

  it("lança 409 se e-mail já estiver em uso por outro customer", async () => {
    // Arrange (variavel quando é colocado _ indica como intencionalemnte nao utlizada _a)
    const _a = await createCustomer.execute(makeCreateCustomerDTO({ email: "a@acme.com" }));
    const b = await createCustomer.execute(makeCreateCustomerDTO({ email: "b@acme.com" }));

    // Act + Assert
    await expect(
      sut.execute(b.id, { name: b.name, email: "a@acme.com" })
    ).rejects.toMatchObject({ statusCode: 409 });
  });

  it("lança 404 se id não existir", async () => {
    await expect(
      sut.execute("uuid-inexistente", { name: "Ghost", email: "ghost@acme.com" })
    ).rejects.toBeInstanceOf(AppError);

    await expect(
      sut.execute("uuid-inexistente", { name: "Ghost", email: "ghost@acme.com" })
    ).rejects.toMatchObject({ statusCode: 404 });
  });

  it("não permite atualizar se estiver soft-deleted (regra de negócio)", async () => {
    // Arrange
    const c = await createCustomer.execute(makeCreateCustomerDTO({ email: "x@acme.com" }));
    await repo.softDelete(c.id);

    // Act + Assert
    await expect(
      sut.execute(c.id, { name: "Xpto", email: c.email })
    ).rejects.toMatchObject({ statusCode: 409 });
  });
});
