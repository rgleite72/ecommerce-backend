// src/modules/customers/tests/unit/get-customer-by-id.service.spec.ts
import { InMemoryCustomersRepository } from "../doubles/in-memory-customers.repository";
import { CreateCustomerService } from "../../services/create-customer.service";
import { GetCustomerByIdService } from "../../services/get-customer-by-id.service";
import { makeCreateCustomerDTO } from "../fixtures/customer.fixture";
import { AppError } from "../../../../shared/errors/AppError";

describe("GetCustomerByIdService", () => {
  it("retorna um customer existente pelo id", async () => {
    const repo = new InMemoryCustomersRepository();
    const create = new CreateCustomerService(repo);
    const getById = new GetCustomerByIdService(repo);

    // 1) cria um cliente e captura o id
    const created = await create.execute(makeCreateCustomerDTO({ email: "john@acme.com" }));

    // 2) busca pelo id
    const found = await getById.execute(created.id);

    expect(found).toBeDefined();
    expect(found.id).toBe(created.id);
    expect(found.email).toBe("john@acme.com");
  });

  it("lança 404 quando não encontrar o id", async () => {
    const repo = new InMemoryCustomersRepository();
    const getById = new GetCustomerByIdService(repo);

    const NOT_FOUND_ID = "00000000-0000-0000-0000-000000000000";

    await expect(getById.execute(NOT_FOUND_ID))
      .rejects.toEqual(new AppError("Customer não encontrado", 404));
  });
});
