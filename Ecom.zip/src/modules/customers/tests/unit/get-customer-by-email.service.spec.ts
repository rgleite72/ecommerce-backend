import { InMemoryCustomersRepository } from "../doubles/in-memory-customers.repository";
import { makeCreateCustomerDTO } from "../fixtures/customer.fixture";
import { CreateCustomerService, GetCustomerByEmailService } from "../../services";

describe("GetCustomerByEmailService", () => {
  let repo: InMemoryCustomersRepository;
  let createCustomer: CreateCustomerService;
  let sut: GetCustomerByEmailService;

  beforeEach(() => {
    repo = new InMemoryCustomersRepository();
    createCustomer = new CreateCustomerService(repo);
    sut = new GetCustomerByEmailService(repo);
  });

  it("retorna o customer pelo e-mail existente", async () => {
    // Arrange
    const email = "teste@teste.com";
    const dto = makeCreateCustomerDTO({ email });
    const created = await createCustomer.execute(dto);

    // Act
    const result = await sut.execute(created.email);

    // Assert
    expect(result).toBeDefined();
    expect(result.email).toBe(created.email);
    expect(result.email).toBe(email);
  });

  it("lança 404 quando e-mail não for encontrado", async () => {
    // Arrange
    const emailInexistente = "naoexiste@teste.com";

    // Act + Assert
    await expect(sut.execute(emailInexistente)).rejects.toMatchObject({ statusCode: 404 });


    // Alternativa mais robusta (evita quebrar se a mensagem mudar levemente):
    // await expect(sut.execute(emailInexistente)).rejects.toBeInstanceOf(AppError);
    // await expect(sut.execute(emailInexistente)).rejects.toMatchObject({ statusCode: 404 });
  });
});
