// src/modules/customers/tests/services/set-last-purchase-info.service.spec.ts
import { InMemoryCustomersRepository } from "../doubles/in-memory-customers.repository";
import { SetLastPurchaseInfoService } from "../../services";
import { CreateCustomerService } from "../../services/create-customer.service";
import { makeCreateCustomerDTO } from "../fixtures/customer.fixture";
import { AppError } from "../../../../shared/errors/AppError";

describe("SetLastPurchaseInfoService", () => {
  let repo: InMemoryCustomersRepository;
  let createCustomer: CreateCustomerService;
  let sut: SetLastPurchaseInfoService;

  beforeEach(() => {
    repo = new InMemoryCustomersRepository();
    createCustomer = new CreateCustomerService(repo);
    sut = new SetLastPurchaseInfoService(repo);
  });

  it("atualiza lastPurchaseAt/lastPurchaseValue e toca updatedAt", async () => {
    // Arrange
    const created = await createCustomer.execute(
      makeCreateCustomerDTO({ email: "teste@teste.com" })
    );
    const id = created.id;
    const beforeMs = created.updatedAt!.getTime();
    const input = { at: new Date("2025-10-10T12:00:00Z"), value: 199.9 };

    // Garante próximo tick (evita empate de ms no updatedAt)
    await new Promise((r) => setTimeout(r, 2));

    // Act
    await sut.execute(id, input);

    // Assert (read-after-write)
    const after = await repo.findById(id);
    expect(after).toBeDefined();
    expect(after!.lastPurchaseAt).toBeInstanceOf(Date);
    expect(Number(after!.lastPurchaseValue)).toBeCloseTo(199.9, 2);

    const afterMs = after!.updatedAt!.getTime();
    expect(afterMs).toBeGreaterThan(beforeMs);

    // Invariantes básicos
    expect(after!.id).toBe(id);
    expect(after!.email).toBe(created.email);
    expect(after!.deletedAt).toBeNull();
  });

  it("lança 404 se customer não existir", async () => {
    await expect(
      sut.execute("uuid-que-nao-existe", { at: new Date(), value: 10 })
    ).rejects.toBeInstanceOf(AppError);

    await expect(
      sut.execute("uuid-que-nao-existe", { at: new Date(), value: 10 })
    ).rejects.toMatchObject({ statusCode: 404 });
  });

  it("lança 400 se value negativo", async () => {
    const c = await createCustomer.execute(makeCreateCustomerDTO());
    await expect(
      sut.execute(c.id, { at: new Date(), value: -1 })
    ).rejects.toMatchObject({ statusCode: 400 });
  });

  it("não permite atualizar se deletado/inativo (se essa for a regra)", async () => {
    const c = await createCustomer.execute(makeCreateCustomerDTO());
    await repo.softDelete(c.id); // simula soft delete no InMemory

    await expect(
      sut.execute(c.id, { at: new Date(), value: 10 })
    ).rejects.toMatchObject({ statusCode: 409 });
  });
});
