// src/modules/customers/tests/unit/delete-customer.service.spec.ts
import { InMemoryCustomersRepository } from "../doubles/in-memory-customers.repository";
import { CreateCustomerService } from "../../services/create-customer.service";
import { DeleteCustomerService } from "../../services/delete-customer.service";
import { makeCreateCustomerDTO } from "../fixtures/customer.fixture";
import { AppError } from "../../../../shared/errors/AppError";

describe("DeleteCustomerService (soft delete)", () => {
  let repo: InMemoryCustomersRepository;
  let createCustomer: CreateCustomerService;
  let sut: DeleteCustomerService;

  beforeEach(() => {
    repo = new InMemoryCustomersRepository();
    createCustomer = new CreateCustomerService(repo);
    sut = new DeleteCustomerService(repo);
  });

  it("marca deletedAt, toca updatedAt e remove do list padrão", async () => {
    // Arrange
    const created = await createCustomer.execute(
      makeCreateCustomerDTO({ email: "delete.me@acme.com", name: "To Delete" })
    );
    const id = created.id;
    const beforeUpdatedMs = created.updatedAt!.getTime();

    // Evita empate de milissegundo no updatedAt
    await new Promise((r) => setTimeout(r, 2));

    // Act
    await sut.execute(id);

    // Assert (read-after-write)
    const after = await repo.findById(id);
    expect(after).toBeDefined();
    expect(after!.deletedAt).toBeInstanceOf(Date);
    expect(after!.updatedAt!.getTime()).toBeGreaterThan(beforeUpdatedMs);

    // Não aparece na listagem padrão (list exige page/limit)
    const listed = await repo.list({ page: 1, limit: 20, email: created.email });
    expect(listed.data).toHaveLength(0);
  });

  it("é idempotente: deletar duas vezes não lança erro", async () => {
    const c = await createCustomer.execute(makeCreateCustomerDTO({ email: "twice@acme.com" }));

    await expect(sut.execute(c.id)).resolves.toBeUndefined();
    await expect(sut.execute(c.id)).resolves.toBeUndefined(); // segunda chamada não deve falhar

    const after = await repo.findById(c.id);
    expect(after).toBeDefined();
    expect(after!.deletedAt).toBeInstanceOf(Date);
  });

  it("lança 404 se id não existir", async () => {
    await expect(sut.execute("uuid-inexistente")).rejects.toBeInstanceOf(AppError);
    await expect(sut.execute("uuid-inexistente")).rejects.toMatchObject({ statusCode: 404 });
  });

  it("permite leitura por id após soft delete (contrato do repo)", async () => {
    const c = await createCustomer.execute(makeCreateCustomerDTO({ email: "visible@acme.com" }));
    await sut.execute(c.id);

    const after = await repo.findById(c.id);
    expect(after).toBeDefined();
    expect(after!.id).toBe(c.id);
    expect(after!.deletedAt).toBeInstanceOf(Date);
  });
});
