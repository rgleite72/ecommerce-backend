import { z } from "zod";

export const updateLastPurchaseSchema = z.object({
  lastPurchaseAt: z.coerce.date().nullable().optional(),
  lastPurchaseValue: z.string().nullable().optional(), // ou z.coerce.number().nullable().optional()
});

export type UpdateLastPurchaseDTO = z.infer<typeof updateLastPurchaseSchema>;
