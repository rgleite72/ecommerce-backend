import { http, ds } from "../../../../tests/config/setup-tests";
import { describe, it } from "@jest/globals";

async function access() {
  const r = await http()
    .post("/api/auth/login")
    .send({ email: "admin@acme.com", password: "admin123" })
    .expect(200);
  return r.body.accessToken as string;
}

describe("RBAC authorize()", () => {
  it("200 quando admin tem 'users.read'", async () => {
    const token = await access();
    await http().get("/api/admin/users").set("Authorization", `Bearer ${token}`).expect(200);
  });

  it("403 quando permissão é removida", async () => {
    await ds().query("DELETE FROM role_permissions WHERE role='admin' AND permission_code='users.read'");
    const token = await access();
    await http().get("/api/admin/users").set("Authorization", `Bearer ${token}`).expect(403);
  });
});
