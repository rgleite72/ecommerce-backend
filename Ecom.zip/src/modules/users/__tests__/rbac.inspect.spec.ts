import { describe, it, expect } from "@jest/globals";
import { http, ds } from "../../../../tests/config/setup-tests";
import { verifyAccess } from "../../../shared/auth/jwt";
import { UserEntity } from "../domain/entities/user.entity";

async function login() {
  const r = await http()
    .post("/api/auth/login")
    .send({ email: "admin@acme.com", password: "admin123" })
    .expect(200);

  const { accessToken, refreshToken, user } = r.body;
 
  console.log("[INSPECT] login.user:", user);
 
  console.log("[INSPECT] access.len:", accessToken?.length, "refresh.len:", refreshToken?.length);
  return { accessToken, refreshToken, user };
}

describe("RBAC INSPECT", () => {
  it("mostra payload do access, usuário no DB e respostas das rotas", async () => {
    const { accessToken } = await login();

    // 1) Decodifica o access e mostra o payload
    const payload = verifyAccess(accessToken) as { sub: string; email?: string; type?: string };

    console.log("[INSPECT] jwt.payload:", payload);

    // 2) Confere o usuário no banco
    const repo = ds().getRepository(UserEntity);
    const u = await repo.findOne({ where: { id: payload.sub } });
   
    console.log("[INSPECT] db.user:", u?.id, u?.email, u?.role);

    // 3) Chama as rotas e loga status/corpo
    const me = await http().get("/api/users/me").set("Authorization", `Bearer ${accessToken}`);
  
    console.log("[INSPECT] /api/users/me →", me.status, me.body);

    const adminUsers = await http().get("/api/admin/users").set("Authorization", `Bearer ${accessToken}`);
  
    console.log("[INSPECT] /api/admin/users →", adminUsers.status, adminUsers.body);

    // Expectativas “brandas” só pra manter o teste rodando
    expect(payload.sub).toBeDefined();
    expect(u?.id).toBe(payload.sub);
  });
});
