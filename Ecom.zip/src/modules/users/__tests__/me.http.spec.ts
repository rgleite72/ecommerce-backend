import { http } from "../../../../tests/config/setup-tests";
import { describe, it, expect } from "@jest/globals";

async function loginAndGetAccess() {
  const r = await http()
    .post("/api/auth/login")
    .send({ email: "admin@acme.com", password: "admin123" })
    .expect(200);
  return r.body.accessToken as string;
}

describe("Users → GET /api/users/me", () => {
  it("401 sem token", async () => {
    await http().get("/api/users/me").expect(401);
  });

  it("200 com token válido", async () => {
    const access = await loginAndGetAccess();
    const res = await http().get("/api/users/me").set("Authorization", `Bearer ${access}`).expect(200);
    expect(res.body.email).toBe("admin@acme.com");
  });
});
