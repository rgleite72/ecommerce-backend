import { Router } from "express";
import { SessionController } from "./controllers/session.controller";
import { rateLimitLogin } from "../../app/middlewares/rate-limit-login";

const sessionController = new SessionController();
export const authRouter = Router();

authRouter.post("/login",  rateLimitLogin, (req, res, next) => sessionController.login(req, res, next));
authRouter.post("/refresh", rateLimitLogin, (req, res, next) => sessionController.refresh(req, res, next));
authRouter.post("/logout",  rateLimitLogin, (req, res, next) => sessionController.logout(req, res, next));
authRouter.post("/logout-all", rateLimitLogin, (req, res, next) => sessionController.logoutAll(req, res, next));


