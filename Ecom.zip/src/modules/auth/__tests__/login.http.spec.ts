import { http } from "../../../../tests/config/setup-tests";
import { describe, it, expect } from "@jest/globals";

describe("Auth → POST /api/auth/login", () => {
  it("200 com access/refresh válidos (admin seed)", async () => {
    const res = await http()
      .post("/api/auth/login")
      .send({ email: "admin@acme.com", password: "admin123" }) // >= 8 chars
      .expect(200);

    expect(res.body).toHaveProperty("accessToken");
    expect(res.body).toHaveProperty("refreshToken");
  });
});
