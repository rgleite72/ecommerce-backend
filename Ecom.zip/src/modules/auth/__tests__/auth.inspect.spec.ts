// src/modules/auth/__tests__/auth.inspect.spec.ts
import { describe, it } from "@jest/globals";
import { ds, http } from "../../../../tests/config/setup-tests";
import bcrypt from "bcrypt";

type DbNameRow = { db: string };
type UserRow = { email: string; role: string; hash_len: number; password_hash: string };
type PermRow = { code: string };
type RolePermRow = { role: string; permission_code: string };

describe("AUTH INSPECT", () => {
  it("dump users/permissions e compara hash", async () => {
    const db = ds();

    // 1) Qual DB?
    const dbNameRows = (await db.query(
      `SELECT current_database() AS db`
    )) as unknown as DbNameRow[];

    // 2) Usuários
    const users = (await db.query(
      `SELECT email, role, LENGTH(password_hash) AS hash_len, password_hash
       FROM users ORDER BY email`
    )) as unknown as UserRow[];

    // 3) Permissões
    const perms = (await db.query(
      `SELECT code FROM permissions ORDER BY code`
    )) as unknown as PermRow[];

    const rperms = (await db.query(
      `SELECT role, permission_code FROM role_permissions ORDER BY role, permission_code`
    )) as unknown as RolePermRow[];

    console.log("INSPECT → DB:", dbNameRows, "\nUSERS:", users, "\nPERMS:", perms, "\nROLE_PERMS:", rperms);

    // 4) Compara hash do admin, se existir
    const admin = users.find((u) => u.email === "admin@acme.com");
    if (admin) {
      const matchAdmin123 = await bcrypt.compare("admin123", admin.password_hash);
      const matchAdminAt123 = await bcrypt.compare("Admin@123", admin.password_hash);
      console.log("COMPARE → admin@acme.com:", { matchAdmin123, matchAdminAt123 });
    } else {
      console.log("COMPARE → admin@acme.com: NOT FOUND");
    }

    // 5) Tenta login “a quente”
    const res = await http()
      .post("/api/auth/login")
      .send({ email: "admin@acme.com", password: "admin123" });
    console.log("LOGIN TRY → status:", res.status, "body:", res.body);
  });
});
