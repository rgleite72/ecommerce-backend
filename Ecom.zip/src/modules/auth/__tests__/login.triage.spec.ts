// src/modules/auth/__tests__/login.triage.spec.ts
import { http } from "../../../../tests/config/setup-tests";
import { describe, it } from "@jest/globals";

interface LoginPayload {
  email: string;
  password: string;
}


async function tryLogin(payload: LoginPayload) {
  const res = await http().post("/api/auth/login").send(payload);
 
  console.log("TRIAGE →", payload, "→", res.status, res.body);
}

describe("LOGIN TRIAGE", () => {
  it("tenta 3 credenciais comuns", async () => {
    await tryLogin({ email: "admin@acme.com", password: "admin123" }); // seed clássico
    await tryLogin({ email: "test@example.com", password: "secret" }); // stub típico
    await tryLogin({ email: "admin@acme.com", password: "Admin@123" }); // política forte
  });
});
