import { http } from "../../../../tests/config/setup-tests";
import { describe, it, expect } from "@jest/globals";

async function login() {
  const r = await http()
    .post("/api/auth/login")
    .send({ email: "admin@acme.com", password: "admin123" })
    .expect(200);
  return { access: r.body.accessToken as string, refresh: r.body.refreshToken as string };
}

describe("Auth → POST /api/auth/refresh", () => {
  it("200 emite novo par e invalida o anterior (rotation)", async () => {
    const a = await login();

    const ref1 = await http()
      .post("/api/auth/refresh")
      .send({ refreshToken: a.refresh })
      .expect(200);

    expect(ref1.body).toHaveProperty("accessToken");
    expect(ref1.body).toHaveProperty("refreshToken");

    await http()
      .post("/api/auth/refresh")
      .send({ refreshToken: a.refresh })
      .expect(401);
  });
});
