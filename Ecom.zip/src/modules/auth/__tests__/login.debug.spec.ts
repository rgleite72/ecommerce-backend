// src/modules/auth/__tests__/login.debug.spec.ts
import { http } from "../../../../tests/config/setup-tests";
import { describe, it } from "@jest/globals";

describe("LOGIN DEBUG", () => {
  it("mostra o corpo do erro do /api/auth/login", async () => {
    const res = await http()
      .post("/api/auth/login")
      .send({ email: "admin@acme.com", password: "admin123" }); // NÃO troque ainda

    // 👇 imprime status e erro de validação (Zod/Class-Validator/etc.)
    
    console.log("LOGIN DEBUG → status:", res.status, "body:", res.body);

    // sem assert aqui — queremos só o log cru
  });
});
