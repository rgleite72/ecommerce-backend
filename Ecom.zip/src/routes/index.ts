// src/routes/index.ts
import { Router } from "express";
import { authRouter } from "../modules/auth/routes";

// ⬇️ importe os routers dos módulos
import usersRouter from "../modules/users/routes";           // default export (routes.ts)
import adminUsersRouter from "../modules/users/admin.routes"; // default export (admin.routes.ts)
import customersRouter from "../modules/customers/routes"; // /api/customers/*


export const router = Router();

// módulos
router.use("/auth", authRouter);
router.use("/users", usersRouter);           // /api/users/*
router.use("/admin/users", adminUsersRouter); // /api/admin/users/*  (comente se não ativar admin)
router.use("/customers", customersRouter);

// healthcheck
router.get("/health", (_req, res) => {
  res.json({ status: "ok" });
});
