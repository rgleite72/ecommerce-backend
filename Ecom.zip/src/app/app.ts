// src/app/app.ts
import express from "express";
import { requestId } from "./middlewares/requestId";
import { loggerHttp } from "./middlewares/logger-http";
import { rateLimitGlobal } from "./middlewares/rate-limit-global";
import { securityMiddlewares } from "./middlewares/security";
import { errorHandler } from "./middlewares/errorHandler";
import { router } from "../routes";

export function createApp() {
  const app = express();

  app.use(express.json());
  app.use(requestId);
  app.use(loggerHttp());
  app.use(securityMiddlewares);
  app.use(rateLimitGlobal);

  // Prefixo único
  app.use("/api", router);

  // Sempre por último
  app.use(errorHandler);

  return app;
}
