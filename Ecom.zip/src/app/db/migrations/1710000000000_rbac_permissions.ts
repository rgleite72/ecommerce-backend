// exemplo: src/app/db/migrations/1710000000000_rbac_permissions.ts
import { MigrationInterface, QueryRunner } from "typeorm";

export class RbacPermissions1710000000000 implements MigrationInterface {
  name = "RbacPermissions1710000000000";

  public async up(q: QueryRunner): Promise<void> {
    await q.query(`
      CREATE TABLE IF NOT EXISTS permissions (
        code VARCHAR(100) PRIMARY KEY,
        description VARCHAR(255),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
      );
    `);

    await q.query(`
      CREATE TABLE IF NOT EXISTS role_permissions (
        role VARCHAR(10) NOT NULL,
        permission_code VARCHAR(100) NOT NULL,
        PRIMARY KEY (role, permission_code),
        CONSTRAINT fk_role_permissions_permission
          FOREIGN KEY (permission_code) REFERENCES permissions(code) ON DELETE CASCADE
      );
    `);
  }

  public async down(q: QueryRunner): Promise<void> {
    await q.query(`DROP TABLE IF EXISTS role_permissions;`);
    await q.query(`DROP TABLE IF EXISTS permissions;`);
  }
}
