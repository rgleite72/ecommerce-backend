// src/app/db/data-source.ts
import "reflect-metadata";
import { DataSource } from "typeorm";

const isTest = process.env.NODE_ENV === "test";

export const appDataSource = new DataSource({
  type: "postgres",
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT ?? 5432),
  username: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME, // .env.test -> commerceBackdb_test
  // ⚠️ Em teste, pode sincronizar o schema para simplificar
  synchronize: isTest, 
  logging: false,
  entities: [__dirname + "/../../**/*.entity.{ts,js}"],
});


export { appDataSource as AppDataSource };